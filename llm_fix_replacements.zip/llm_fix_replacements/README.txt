Files included:
- generate/trailtraining_compat.py
- generate/fit_priors.py
- slurm/run_generation_hpc.sh
- tests/test_llm_semantic_guard.py

Apply from repo root with either:
  bash /path/to/llm_fix_replacements/APPLY_FILES.sh .

Or copy the files manually into the matching repo paths.

Then validate with:
  pytest -q tests/test_llm_semantic_guard.py
  python tests/run_tests.py
