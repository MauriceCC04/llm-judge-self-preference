#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
REPO_TARGET="${1:-$(pwd)}"
install -d "$REPO_TARGET/generate" "$REPO_TARGET/slurm" "$REPO_TARGET/tests"
cp "$ROOT/generate/trailtraining_compat.py" "$REPO_TARGET/generate/trailtraining_compat.py"
cp "$ROOT/generate/fit_priors.py" "$REPO_TARGET/generate/fit_priors.py"
cp "$ROOT/slurm/run_generation_hpc.sh" "$REPO_TARGET/slurm/run_generation_hpc.sh"
chmod +x "$REPO_TARGET/slurm/run_generation_hpc.sh"
cp "$ROOT/tests/test_llm_semantic_guard.py" "$REPO_TARGET/tests/test_llm_semantic_guard.py"
echo "Applied replacement files into: $REPO_TARGET"
